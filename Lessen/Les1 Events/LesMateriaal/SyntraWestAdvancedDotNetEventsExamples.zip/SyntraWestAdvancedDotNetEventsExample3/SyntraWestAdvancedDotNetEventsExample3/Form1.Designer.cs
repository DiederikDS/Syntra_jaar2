﻿namespace SyntraWestAdvancedDotNetEventsExample3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnShowWindow = new System.Windows.Forms.Button();
            this.btnHideButton = new System.Windows.Forms.Button();
            this.btnToggleButton = new System.Windows.Forms.Button();
            this.btnDisableButton = new System.Windows.Forms.Button();
            this.btnRandomColor = new System.Windows.Forms.Button();
            this.btnCloseWindow = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnShowWindow
            // 
            this.btnShowWindow.Location = new System.Drawing.Point(12, 12);
            this.btnShowWindow.Name = "btnShowWindow";
            this.btnShowWindow.Size = new System.Drawing.Size(113, 100);
            this.btnShowWindow.TabIndex = 0;
            this.btnShowWindow.Text = "Show message";
            this.btnShowWindow.UseVisualStyleBackColor = true;
            this.btnShowWindow.Click += new System.EventHandler(this.btnShowWindow_Click);
            // 
            // btnHideButton
            // 
            this.btnHideButton.Location = new System.Drawing.Point(131, 12);
            this.btnHideButton.Name = "btnHideButton";
            this.btnHideButton.Size = new System.Drawing.Size(113, 100);
            this.btnHideButton.TabIndex = 1;
            this.btnHideButton.Text = "Hide button";
            this.btnHideButton.UseVisualStyleBackColor = true;
            this.btnHideButton.Click += new System.EventHandler(this.btnHideButton_Click);
            // 
            // btnToggleButton
            // 
            this.btnToggleButton.Location = new System.Drawing.Point(250, 12);
            this.btnToggleButton.Name = "btnToggleButton";
            this.btnToggleButton.Size = new System.Drawing.Size(113, 100);
            this.btnToggleButton.TabIndex = 2;
            this.btnToggleButton.Text = "Toggle other button";
            this.btnToggleButton.UseVisualStyleBackColor = true;
            this.btnToggleButton.Click += new System.EventHandler(this.btnToggleButton_Click);
            // 
            // btnDisableButton
            // 
            this.btnDisableButton.Location = new System.Drawing.Point(12, 118);
            this.btnDisableButton.Name = "btnDisableButton";
            this.btnDisableButton.Size = new System.Drawing.Size(113, 100);
            this.btnDisableButton.TabIndex = 3;
            this.btnDisableButton.Text = "Disable other button";
            this.btnDisableButton.UseVisualStyleBackColor = true;
            this.btnDisableButton.Click += new System.EventHandler(this.btnDisableButton_Click);
            // 
            // btnRandomColor
            // 
            this.btnRandomColor.Location = new System.Drawing.Point(131, 118);
            this.btnRandomColor.Name = "btnRandomColor";
            this.btnRandomColor.Size = new System.Drawing.Size(113, 100);
            this.btnRandomColor.TabIndex = 4;
            this.btnRandomColor.Text = "Random color";
            this.btnRandomColor.UseVisualStyleBackColor = true;
            this.btnRandomColor.Click += new System.EventHandler(this.btnRandomColor_Click);
            // 
            // btnCloseWindow
            // 
            this.btnCloseWindow.Location = new System.Drawing.Point(250, 118);
            this.btnCloseWindow.Name = "btnCloseWindow";
            this.btnCloseWindow.Size = new System.Drawing.Size(113, 100);
            this.btnCloseWindow.TabIndex = 5;
            this.btnCloseWindow.Text = "Close window";
            this.btnCloseWindow.UseVisualStyleBackColor = true;
            this.btnCloseWindow.Click += new System.EventHandler(this.btnCloseWindow_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 229);
            this.Controls.Add(this.btnCloseWindow);
            this.Controls.Add(this.btnRandomColor);
            this.Controls.Add(this.btnDisableButton);
            this.Controls.Add(this.btnToggleButton);
            this.Controls.Add(this.btnHideButton);
            this.Controls.Add(this.btnShowWindow);
            this.Name = "Form1";
            this.Text = "Mouse click event example";
            this.ResumeLayout(false);

        }

        #endregion

        private Button btnShowWindow;
        private Button btnHideButton;
        private Button btnToggleButton;
        private Button btnDisableButton;
        private Button btnRandomColor;
        private Button btnCloseWindow;
    }
}