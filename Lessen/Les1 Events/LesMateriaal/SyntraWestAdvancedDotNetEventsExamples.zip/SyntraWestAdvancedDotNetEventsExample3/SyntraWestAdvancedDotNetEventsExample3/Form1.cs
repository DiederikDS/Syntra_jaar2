namespace SyntraWestAdvancedDotNetEventsExample3
{
    public partial class Form1 : Form
    {
        private Random _random = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnShowWindow_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello world!");
        }

        private void btnHideButton_Click(object sender, EventArgs e)
        {
            btnHideButton.Visible = false;
            //var button = (Button)sender;
            //button.Visible = false;
        }

        private void btnToggleButton_Click(object sender, EventArgs e)
        {
            btnDisableButton.Visible = !btnDisableButton.Visible;
        }

        private void btnDisableButton_Click(object sender, EventArgs e)
        {
            btnRandomColor.Enabled = !btnRandomColor.Enabled;
        }

        private void btnRandomColor_Click(object sender, EventArgs e)
        {
            btnRandomColor.BackColor = Color.FromArgb(_random.Next(256), _random.Next(256), _random.Next(256));
        }

        private void btnCloseWindow_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}