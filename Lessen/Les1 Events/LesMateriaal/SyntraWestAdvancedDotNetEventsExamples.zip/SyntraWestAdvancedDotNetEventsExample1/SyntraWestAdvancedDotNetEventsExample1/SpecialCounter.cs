﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SyntraWestAdvancedDotNetEventsExample1
{
    public class SpecialCounter
    {
        private int counter;

        public event EventHandler DivisableBy5;

        public SpecialCounter()
        {
        }

        public void Add()
        {
            counter++;
            if (counter % 5 == 0)
            {
                DivisableBy5?.Invoke(this, new EventArgs());
            }
        }
    }
}
