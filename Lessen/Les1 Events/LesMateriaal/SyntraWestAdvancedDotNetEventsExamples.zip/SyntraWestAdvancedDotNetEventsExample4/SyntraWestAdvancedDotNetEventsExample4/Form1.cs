namespace SyntraWestAdvancedDotNetEventsExample4
{
    public partial class Form1 : Form
    {
        private bool _mouseEventEnabled = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (_mouseEventEnabled)
            {
                this.MouseMove -= Form1_MouseMove;
                _mouseEventEnabled = false; 
            }
            else
            {
                this.MouseMove += Form1_MouseMove;
                _mouseEventEnabled = true;
            }
        }

        private void Form1_MouseMove(object? sender, MouseEventArgs e)
        {
            var newLocation = e.Location;
            newLocation.Offset(-10, -10);
            btnStart.Location = newLocation;
        } 
    }
}