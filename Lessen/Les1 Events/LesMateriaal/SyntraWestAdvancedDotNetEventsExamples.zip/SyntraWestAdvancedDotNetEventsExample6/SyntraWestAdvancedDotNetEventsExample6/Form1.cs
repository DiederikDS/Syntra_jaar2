namespace SyntraWestAdvancedDotNetEventsExample6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            timerTest.Start();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timerTest.Stop();
        }

        private void timerTest_Tick(object sender, EventArgs e)
        {
            txtLog.Text += DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss:fff") + Environment.NewLine;
        }
    }
}