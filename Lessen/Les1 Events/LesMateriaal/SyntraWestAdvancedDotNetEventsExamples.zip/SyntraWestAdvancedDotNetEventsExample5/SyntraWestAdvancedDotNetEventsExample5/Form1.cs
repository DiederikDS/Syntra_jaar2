namespace SyntraWestAdvancedDotNetEventsExample5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            lblKeyLogger.Text += e.KeyCode.ToString();
            if (ModifierKeys.HasFlag(Keys.Control))
            {
                if (e.KeyCode == Keys.C)
                {
                    lblCTRLKeyLogger.Text += e.KeyCode.ToString();
                    lblCTRLKeyLogger.Text += Clipboard.GetText();
                }
            }
        }
    }
}