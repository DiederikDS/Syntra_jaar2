﻿namespace SyntraWestAdvancedDotNetEventsExample5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblKeyLogger = new System.Windows.Forms.Label();
            this.lblCTRLKeyLogger = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Keylogger:";
            // 
            // lblKeyLogger
            // 
            this.lblKeyLogger.AutoSize = true;
            this.lblKeyLogger.Location = new System.Drawing.Point(12, 44);
            this.lblKeyLogger.Name = "lblKeyLogger";
            this.lblKeyLogger.Size = new System.Drawing.Size(0, 15);
            this.lblKeyLogger.TabIndex = 1;
            // 
            // lblCTRLKeyLogger
            // 
            this.lblCTRLKeyLogger.AutoSize = true;
            this.lblCTRLKeyLogger.Location = new System.Drawing.Point(12, 189);
            this.lblCTRLKeyLogger.Name = "lblCTRLKeyLogger";
            this.lblCTRLKeyLogger.Size = new System.Drawing.Size(0, 15);
            this.lblCTRLKeyLogger.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "CTRL + Keylogger:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 388);
            this.Controls.Add(this.lblCTRLKeyLogger);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblKeyLogger);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Key event example";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label lblKeyLogger;
        private Label lblCTRLKeyLogger;
        private Label label3;
    }
}