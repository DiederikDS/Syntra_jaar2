﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SyntraWestAdvancedDotNetLinqExample1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private List<int> numbers;

        public MainWindow()
        {
            InitializeComponent();

            numbers = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            UnfilteredList.ItemsSource = numbers;
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            //oneven nummers filteren
            FilteredList.ItemsSource = from number in numbers
                                       where number % 2 == 0
                                       select number;
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            //alle nummers groter dan 5
            FilteredList.ItemsSource = from number in numbers
                                       where number > 5
                                       select number;
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            //alle nummers deelbaar door 3
            FilteredList.ItemsSource = from number in numbers
                                       where number % 3 == 0
                                       select number;
        }

        private void Button4_Click(object sender, RoutedEventArgs e)
        {
            //oneven nummers filteren
            FilteredList.ItemsSource = numbers.Where(number => number % 2 == 0).Select(number => number);
        }

        private void Button5_Click(object sender, RoutedEventArgs e)
        {
            //alle nummers kleiner dan 5
            FilteredList.ItemsSource = numbers.Where(e => e < 5);
        }
    }
}
