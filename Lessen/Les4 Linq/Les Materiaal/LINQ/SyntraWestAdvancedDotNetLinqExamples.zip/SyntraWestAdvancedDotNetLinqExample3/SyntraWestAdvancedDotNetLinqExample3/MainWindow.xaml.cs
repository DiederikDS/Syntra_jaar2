﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SyntraWestAdvancedDotNetLinqExample3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Student> students;

        public MainWindow()
        {
            InitializeComponent();

            students = new List<Student>()
            {
                new Student() { Age = 22, FirstName = "Foe", LastName = "Bar", Course = "C#" },
                new Student() { Age = 32, FirstName = "Bart", LastName = "De Wever", Course = "C#" },
                new Student() { Age = 35, FirstName = "Wim", LastName = "Koopman", Course = "C++" },
                new Student() { Age = 24, FirstName = "Els", LastName = "Dury", Course = "C++" },
                new Student() { Age = 47, FirstName = "Karolien", LastName = "Smet", Course = "C#" },
                new Student() { Age = 33, FirstName = "Jens", LastName = "Bastiaens", Course = "C#" },
            };

            UnfilteredList.DisplayMemberPath = "FirstName";
            UnfilteredList.ItemsSource = students;
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            //Aantal cursisten tonen per cursus
            FilteredList.ItemsSource = from student in students
                                       group student by student.Course into courseGroup
                                       select courseGroup.Key + ": " + courseGroup.Count();
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            //groeperen op leeftijd per 10
            FilteredList.ItemsSource = from student in students
                                       group student by student.Age / 10 into courseGroup
                                       select string.Format("{0}-{1} jaar: {2}",courseGroup.Key * 10, (courseGroup.Key + 1) * 10, courseGroup.Count());
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            //Aantal cursisten tonen per cursus
            FilteredList.ItemsSource = students.GroupBy(student => student.Course).Select(courseGroup => courseGroup.Key + ": " + courseGroup.Count());
        }

        private void Button4_Click(object sender, RoutedEventArgs e)
        {
            //groeperen op leeftijd per 10
            FilteredList.ItemsSource = students.GroupBy(student => student.Age / 10).Select(ageGroup => $"{ageGroup.Key * 10}-{(ageGroup.Key + 1) * 10} jaar: {ageGroup.Count()}");
        }
    }
}
