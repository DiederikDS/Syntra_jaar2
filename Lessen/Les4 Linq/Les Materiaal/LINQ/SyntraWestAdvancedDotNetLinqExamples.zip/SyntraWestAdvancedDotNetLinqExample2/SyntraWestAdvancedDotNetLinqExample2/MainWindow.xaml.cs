﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SyntraWestAdvancedDotNetLinqExample2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Student> students;

        public MainWindow()
        {
            InitializeComponent();

            students = new List<Student>()
            {
                new Student() { Age = 22, FirstName = "Foe", LastName = "Bar", Course = "C#" },
                new Student() { Age = 32, FirstName = "Bart", LastName = "De Wever", Course = "C#" },
                new Student() { Age = 35, FirstName = "Wim", LastName = "Koopman", Course = "C++" },
                new Student() { Age = 24, FirstName = "Els", LastName = "Dury", Course = "C++" },
                new Student() { Age = 47, FirstName = "Karolien", LastName = "Smet", Course = "C#" },
                new Student() { Age = 33, FirstName = "Jens", LastName = "Bastiaens", Course = "C#" },
            };

            UnfilteredList.DisplayMemberPath = "FirstName";
            UnfilteredList.ItemsSource = students;
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            //Iedereen ouder dan 30
            FilteredList.ItemsSource = from student in students
                                       where student.Age > 30
                                       select student.FirstName;
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            //Iedereen die C# volgt
            FilteredList.ItemsSource = from student in students
                                       where student.Course == "C#"
                                       select student.FirstName + " " + student.LastName;
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            //Iedereen met de letter "d" in de achternaam
            FilteredList.ItemsSource = from student in students
                                       where student.LastName.ToLower().Contains('d')
                                       select string.Format("{0} {1} ({2})", student.FirstName, student.LastName, student.Age);
        }

        private void Button4_Click(object sender, RoutedEventArgs e)
        {
            //Iedereen jonger is dan 30
            FilteredList.ItemsSource = students.Where(e => e.Age < 30).Select(e => e.FirstName);
        }

        private void Button5_Click(object sender, RoutedEventArgs e)
        {
            //Iedereen die C++ volgt
            FilteredList.ItemsSource = students.Where(e => e.Course == "C++").Select(e => $"{e.FirstName} {e.LastName} ({e.Age})");
        }
    }
}
