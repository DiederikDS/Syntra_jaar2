﻿// See https://aka.ms/new-console-template for more information
// read file and it exists (no exception)
try
{
    var result = File.ReadAllLines(Directory.GetCurrentDirectory() + "/input.txt");
    foreach (var line in result)
    {
        Console.WriteLine(line);
    }
}
catch (Exception ex)
{
    throw new Exception("Dit loopt hier fout!", ex);
}
finally
{
    Console.WriteLine("Finally");
}

Console.Write(Environment.NewLine);

Console.ReadKey();

// read file and directory does not exists
try
{
    var result = File.ReadAllLines(Directory.GetCurrentDirectory() + "dirnotexists/input.txt");
    foreach (var line in result)
    {
        Console.WriteLine(line);
    }
}
//Catches all exceptions
catch (Exception ex)
{
    Console.WriteLine("Exception");
}
finally
{
    Console.WriteLine("Finally");
}

Console.Write(Environment.NewLine);

// read file and directory does not exists
try
{
    var result = File.ReadAllLines(Directory.GetCurrentDirectory() + "dirnotexists/input.txt");
    foreach (var line in result)
    {
        Console.WriteLine(line);
    }
}
//Catch all other exceptions

//Catching specific exceptions
catch (ArgumentNullException ex)
{
    Console.WriteLine("ArgumentNullException");
}
catch (FileNotFoundException ex)
{
    Console.WriteLine("FileNotFoundException");
}
catch (DirectoryNotFoundException ex)
{
    Console.WriteLine("DirectoryNotFoundException");
}
catch (Exception ex)
{
    //does not come here, because error was catched in DirectoryNotFoundException
    Console.WriteLine("Exception");
}
finally
{
    Console.WriteLine("Finally");
}

Console.ReadLine();