﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SyntraWestAdvancedDotNetErrorHandlingExample2
{
    public class AnimalCollection
    {
        private List<string> _animals;

        public List<string> Animals
        {
            get { return _animals; }
            set { _animals = value; }
        }

        public AnimalCollection()
        {
            Animals = new List<string>();
        }

        //Adds all the animals to the list. name cannot contain the letter "z"
        public void AddAnimal(string name)
        {
            if (name.ToLower().Contains("z"))
            {
                throw new AnimalException("The name: '" + name + "' may not contain the letter \"z\"!");
            }
            Animals.Add(name);
        }

        public override string ToString()
        {
            string stringResult = "";

            foreach (var animal in Animals)
            {
                stringResult += animal + Environment.NewLine;
            }

            return stringResult;
        }
    }
}
