﻿using SyntraWestAdvancedDotNetErrorHandlingExample2;

//Creating a new animal collection
AnimalCollection myCollection = new AnimalCollection();

//Adding new animals
try
{
    myCollection.AddAnimal("Code monkey");

    myCollection.AddAnimal("Mouse");

    myCollection.AddAnimal("Bird");

    //Adding an animal with the letter "Z"
    myCollection.AddAnimal("Zebra");

    myCollection.AddAnimal("Dog");
}
catch (AnimalException ex)
{
    Console.WriteLine(ex.ToString());
}
finally
{
    myCollection.AddAnimal("Cat");
}

Console.Write(Environment.NewLine);

//Collection does not contain Zebra and Dog (dog was not added because error was thrown)
Console.WriteLine(myCollection.ToString());

Console.ReadLine();

