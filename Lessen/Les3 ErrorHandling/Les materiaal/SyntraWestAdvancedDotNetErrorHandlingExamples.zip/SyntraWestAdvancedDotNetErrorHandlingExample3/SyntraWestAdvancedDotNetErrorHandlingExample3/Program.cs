﻿// See https://aka.ms/new-console-template for more information

using SyntraWestAdvancedDotNetErrorHandlingExample3;

try
{
    //Generating error (file does not exist)
    var result = File.ReadAllLines(Directory.GetCurrentDirectory() + "/input.txt");
    foreach (var line in result)
    {
        Console.WriteLine(line);
    }
}
catch (Exception ex)
{
    //Writing the error in a log
    //We are now using a self made class which logs to a file.
    //Multiple 3rd party logging is also available with text logging, event logging, mailing, database entries, ...
    CustomFileLog.AddErrorLog(ex.Message);
}